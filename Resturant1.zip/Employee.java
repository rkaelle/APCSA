public class Employee
  {
    protected String name;
    protected int employeeNo;
    protected String job;
    protected double salary;
	
  public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
    

    public Employee(int employeeNo, String name, String job, double salary){
      this.employeeNo = employeeNo;
      this.job = job;
      this.name = name;
      this.salary = salary;
      }
    public String toString(){
      return "This employee's number is: " + employeeNo + "\nTheir name is: "+ name + "\nThey work late nights as a: "+ job + "\nThey have a salary of: $"+ salary + "\nThey are a "+ salary;
    }
  }
  