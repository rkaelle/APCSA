public class Restaurant
{
  String address;
  String name;
  String phoneNo;
  String rating;
  String cuisineType;
  private Menu menu;
  private Menu menu5;
  private Employee employee;
  private Chef chef;
  private Waiter waiter;




public Restaurant(String address, String name, String phoneNo, String rating, String cuisineType){
    this.address = address;
    this.name = name;
    this.phoneNo = phoneNo;
    this.rating = rating;
    this.cuisineType = cuisineType;
    menu = new Menu("lunch");
    menu5 = new Menu("breakfast");
    chef = new Chef(45, "fillipo", "chef", 80000, "veal cordon bleu");
    waiter = new Waiter(43, "pete", "waiter", 65000,500);
  }

  public String getCheck(){
    return "The resturant generated $"+ (menu.getSpecialCost() + menu5.getSpecialCost()) + "\nThis means they can no longer afford to pay for thier employees like " + chef.getName();
  }

public Waiter getWaiter() {
	return waiter;
}

public void setWaiter(Waiter waiter) {
	this.waiter = waiter;
}
  
public Chef getChef() {
	return chef;
}

public void setChef(Chef chef) {
	this.chef = chef;
}
  
public Employee getEmployee() {
	return employee;
}


public void setEmployee(Employee employee) {
	this.employee = employee;
}


public Menu getMenu() {
	return menu;
}
  

public void setMenu(Menu menu) {
	this.menu = menu;
}

public Menu getMenu5() {
	return menu;
}
  

public void setMenu5(Menu menu) {
	this.menu = menu;
}
  
public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getPhoneNo() {
	return phoneNo;
}

public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}

public String getRating() {
	return rating;
}

public void setRating(String rating) {
	this.rating = rating;
}

public String getCuisineType() {
	return cuisineType;
}

public void setCuisineType(String cuisineType) {
	this.cuisineType = cuisineType;
}

public String toString(){
  return "Address: "+ address +"\nName: "+ name +"\nPhone Number: "+ phoneNo +"\nRating: "+ rating +"\nCuisine Type: "+ cuisineType;
}
  
}