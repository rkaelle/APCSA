public class Menu
  {

    private String special;
    private double specialCost;
    private String mealType;
    
  public String getSpecial() {
		return special;
	}

	public void setSpecial(String special) {
		this.special = special;
	}

	public double getSpecialCost() {
		return specialCost;
	}

	public void setSpecialCost(double specialCost) {
		this.specialCost = specialCost;
	}

	public String getMealType() {
		return mealType;
	}

	public void setMealType(String mealType) {
		this.mealType = mealType;
	}


    public Menu(String mealType){
      this.mealType = mealType;
      if (mealType.equals("lunch")){
        special = "blt";
        specialCost = 12.50;
      } if (mealType.equals("breakfast")){
        special = "eggs and ham";
        specialCost = 69.50;
      }
    }

    public String toString(){
      return "You ordered the "+mealType + ": " + special + "\nThe total bill is: $" + specialCost;
    }
  }