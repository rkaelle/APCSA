class Main {
  public static void main(String[] args) {
    System.out.println();
    Restaurant barf = new Restaurant("275 Sundown Terrace","Zach's center!","(925) 280-3930","0 out of 8","American");
    System.out.println(barf);
    System.out.println();
    System.out.println(barf.getMenu());
    System.out.println();
    System.out.println(barf.getChef());
    System.out.println();
    System.out.println(barf.getWaiter());
    System.out.println();
    System.out.println(barf.getMenu5());
    System.out.println();
    System.out.println(barf.getCheck());
  }
}