public class Chef extends Employee
{
  String masterDish;

  public Chef(int employeeNo, String name, String job, double salary, String masterDish)
  {
    super(employeeNo, name,job, salary);
    this.masterDish = masterDish;
  }

  public String toString(){
    return super.toString() + "\nMaster Dish: "+ masterDish;
  }
}