public class Waiter extends Employee{
  double tips;
  
  public Waiter(int employeeNo, String name, String job, double salary, double tips){
    super(employeeNo, name ,job, salary);
    this.tips = tips;
  }

  
public void setTips(double newTips){
  tips = newTips;
}
  
public double getTips(){
  return tips;
}



public String toString(){
  return (super.toString()+" and makes $"+ tips +" in tips\n"+ name + " now makes a salary of " + (salary + tips));
  }
}